# NotRistAtAll
Un mini proyecto de Machine Learning, con el equipo BesGrupEva de coder.

Objetivo
Identificar la calificación crediticia (Credit_Score), de un cliente y calificarla en base a tres niveles posibles “Good (1) & Poor (0)”.

**Referencias y Fuente de datos https://www.kaggle.com/datasets/parisrohan/credit-score-classification**

Equipo: Maximiliano Romero | Rodrigo Hidalgo | Raul Garcia
